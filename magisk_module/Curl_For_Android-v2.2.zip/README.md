# Curl For Android
This module installs the latest version of curl with zlib and openssl support

## Compatibility
* Android Lollipop - Pie
* All root solutions

## Change Log
### v2.2 - 1.4.2020
* Switch from Unity to MMT-Ex

### v2.1 - 12.30.2019
* Update to Unity v5.0
* Not compatible with Q+ for reasons unknown - DNS error - no need for this anyways since curl is built-in to Q+

### v2.0 - 12.13.2019
* Complete rewrite of compile script
* Tons of fixes and updates (curl 7.67.0, switched to boringssl - fixed ssl issues, tons more stuff added)
* Now dynamic binary

### v1.2 - 8.11.2019
* Unity v4.4 update

### v1.1 - 7.18.2019
* Update to curl v7.65.2 and openssl 1.1.1c

### v1.0 - 5.28.2019
* Initial release

## Credits
* [Daniel Stenberg](https://curl.haxx.se/)
* [robertying](https://github.com/robertying)

## Source Code
* Module [GitHub](https://github.com/Zackptg5/Curl-For-Android)
* Build Script [Github](https://github.com/Zackptg5/curl-boringssl-android)

## Support
[XDA](https://forum.xda-developers.com/android/software-hacking/mods-zackptg5-s-misc-projects-t3881164)
