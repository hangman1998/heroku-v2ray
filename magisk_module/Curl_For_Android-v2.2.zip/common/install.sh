mv -f $MODPATH/common/$ARCH $MODPATH/system
